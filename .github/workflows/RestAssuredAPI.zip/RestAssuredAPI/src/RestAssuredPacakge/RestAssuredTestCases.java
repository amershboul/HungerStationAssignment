package RestAssuredPacakge;

import org.testng.annotations.Test;

import java.util.Random;
import java.util.UUID;

import org.testng.Assert;
//import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import RestAssuredFramework.RestAssuredFramework;

public class RestAssuredTestCases extends RestAssuredFramework {
	
	
	@Test
	public void AddNewPetToStoreWithName()
	{
		String getPetID = AddNewPetToStore("Pet Name Here");
	}
	
	@Test
	public void AddNewPetToStoreThenFindIt()
	{
		String getPetID = AddNewPetToStore("HungerStationName");
		FindPetByIdNumber(getPetID);
	}	
		  
	@Test
	public void AddNewPetThenDeleteIt()
	{
		String uniqueID = UUID.randomUUID().toString();
		String getPetID = AddNewPetToStore(uniqueID);
		DeletesApet(getPetID);
	}		
	
  
	@Test
	public void AddNewUserToSystemWithDetails()
	{
		String uniqueID = UUID.randomUUID().toString();
		AddNewUserToSystems(uniqueID,"FirstName","LastName","a@b.com","12345678","0500000000");
	}		
	
	@Test
	public void getUserFromSystem()
	{
		String uniqueID = UUID.randomUUID().toString();
		AddNewUserToSystems(uniqueID,"FirstName","LastName","a@b.com","12345678","0500000000");
		GetUserByUsername(uniqueID);
	}		
	
	@Test
	public void AddNewUserToSystemThenLogin()
	{
		String uniqueID = UUID.randomUUID().toString();
		AddNewUserToSystems(uniqueID,"FirstName","LastName","a@b.com","12345678","0500000000");
		LogsUserIntoTheSystem(uniqueID,"12345678");
	}		
	
	@Test
	public void AddNewUserToSystemThenLoginThenLogout()
	{
		String uniqueID = UUID.randomUUID().toString();
		AddNewUserToSystems(uniqueID,"FirstName","LastName","a@b.com","12345678","0500000000");
		LogsUserIntoTheSystem(uniqueID,"12345678");
		LogsoutCurrentLoggedinUserSession();
	}	
	
	@Test
	public void CheckAndReturnsPetInventoriesByStatus()
	{
		ReturnsPetInventoriesByStatus();
	}	
	
	@Test
	public void AddNewPetThenPlaceOrder()
	{
		String uniqueID = UUID.randomUUID().toString();
		String getPetID = AddNewPetToStore(uniqueID);
		PlaceAnOrderForPet(getPetID);
	}
	
	
	@Test
	public void FindPurchaseOrderByNumber()
	{
		/*As per the site we will enter any value between 1 and 10*/
		FindPurchaseOrderById("4");
	}	
	
	
	
}
