package RestAssuredFramework;

import org.json.simple.JSONObject;
import org.testng.Assert;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import static io.restassured.RestAssured.given;



public class RestAssuredFramework {

	

	public String AddNewPetToStore(String petName)
	{ 
		
		String payload = "{\n" + 
				"  \"id\": 0,\n" + 
				"  \"category\": {\n" + 
				"    \"id\": 0,\n" + 
				"    \"name\": \"string\"\n" + 
				"  },\n" + 
				"  \"name\": \""+ petName + "\",\n" + 
				"  \"photoUrls\": [\n" + 
				"    \"string\"\n" + 
				"  ],\n" + 
				"  \"tags\": [\n" + 
				"    {\n" + 
				"      \"id\": 0,\n" + 
				"      \"name\": \"string\"\n" + 
				"    }\n" + 
				"  ],\n" + 
				"  \"status\": \"available\"\n" + 
				"}";
		
		String getResponse = given()
        .contentType(ContentType.JSON)
        .body(payload)
        .post("https://petstore.swagger.io/v2/pet")
        .then()
        .statusCode(200)
        .extract()
        .response().path("id").toString();
		
		//String responseBody = getResponse;
		//System.out.println("Response Body is =>  " + responseBody);
		
		return getResponse;
	}
	
	

	public void AddNewUserToSystems(String username, String firstname, String lastname, String email, String password, String mobile)
	{ 
		
		String payload = "[\n" + 
				"  {\n" + 
				"    \"id\": 0,\n" + 
				"    \"username\": \"" + username + "\",\n" + 
				"    \"firstName\": \"" + firstname + "\",\n" + 
				"    \"lastName\": \"" + lastname + "\",\n" + 
				"    \"email\": \"" + email + "\",\n" + 
				"    \"password\": \"" + password + "\",\n" + 
				"    \"phone\": \"" + mobile + "\",\n" + 
				"    \"userStatus\": 0\n" + 
				"  }\n" + 
				"]";
		
		given()
        .contentType(ContentType.JSON)
        .body(payload)
        .post("https://petstore.swagger.io/v2/user/createWithArray")
        .then()
        .statusCode(200)
        .extract()
        .response();
		
	
	}
	
	
	 public void FindPetByIdNumber(String petId)
	 {   
		 RestAssured.baseURI = "https://petstore.swagger.io/v2/pet";		 
		 RequestSpecification httpRequest = RestAssured.given();
		 Response response = httpRequest.request(Method.GET, "/"+ petId);
		
		 int statusCode = response.getStatusCode();
		 
		 Assert.assertEquals(statusCode /*actual value*/, 200 /*expected value*/, "Correct status code returned");
		 
	 }

	
	public void PlaceAnOrderForPet(String petId)
	{ 
		
		String payload = "{\n" + 
				"  \"id\": 0,\n" + 
				"  \"petId\": "+  petId + ",\n" + 
				"  \"quantity\": 0,\n" + 
				"  \"shipDate\": \"2020-06-07T20:05:13.416Z\",\n" + 
				"  \"status\": \"placed\",\n" + 
				"  \"complete\": true\n" + 
				"}";
		
		 given()
        .contentType(ContentType.JSON)
        .body(payload)
        .post("https://petstore.swagger.io/v2/store/order")
        .then()
        .statusCode(200)
        .extract()
        .response();


	}

		 public void FindPurchaseOrderById(String Id)
		 {   
			 RestAssured.baseURI = "https://petstore.swagger.io/v2/store/order";
	
			 RequestSpecification httpRequest = RestAssured.given();
			 
			 Response response = httpRequest.request(Method.GET, "/"+ Id);
			 
			 int statusCode = response.getStatusCode();
			 
			 Assert.assertEquals(statusCode /*actual value*/, 200 /*expected value*/, "Correct status code returned");

		 }
		 

		 public void ReturnsPetInventoriesByStatus()
		 {   
			 RestAssured.baseURI = "https://petstore.swagger.io/v2/store/inventory";
			 
			 RequestSpecification httpRequest = RestAssured.given();
			 
			 Response response = httpRequest.request(Method.GET, "");
			 
			 int statusCode = response.getStatusCode();
			 
			 Assert.assertEquals(statusCode /*actual value*/, 200 /*expected value*/, "Correct status code returned");
			 
		 }
		 
		 
		
		 public void GetUserByUsername(String username)
		 {   
			 RestAssured.baseURI = "https://petstore.swagger.io/v2/user";
			 RequestSpecification httpRequest = RestAssured.given();
			 
			 Response response = httpRequest.request(Method.GET, "/"+ username);
			 
			 int statusCode = response.getStatusCode();
			 
			 Assert.assertEquals(statusCode /*actual value*/, 200 /*expected value*/, "Correct status code returned");		 
		 }	
		 
		
		 public void LogsUserIntoTheSystem(String username, String password)
		 {   
			 RestAssured.baseURI = "https://petstore.swagger.io/v2/user";
			 
			 RequestSpecification httpRequest = RestAssured.given();

			 Response response = httpRequest.request(Method.GET, "/login?username="+ username +"&password="+ password);
			 
			 int statusCode = response.getStatusCode();
			 
			 Assert.assertEquals(statusCode /*actual value*/, 200 /*expected value*/, "Correct status code returned");
		 
		 }	
		 
		 
		 public void LogsoutCurrentLoggedinUserSession()
		 {   
			 RestAssured.baseURI = "https://petstore.swagger.io/v2/user";
			 
			 RequestSpecification httpRequest = RestAssured.given();
			 
			 Response response = httpRequest.request(Method.GET, "/logout");
			 
			 int statusCode = response.getStatusCode();
			 
			 Assert.assertEquals(statusCode /*actual value*/, 200 /*expected value*/, "Correct status code returned");

		 
		 }
		 
			public void DeletesApet(String petid)
			{ 

				 RestAssured.baseURI = "https://petstore.swagger.io/v2/pet";
				 RequestSpecification request = RestAssured.given(); 
				 
				 request.header("Content-Type", "application/json"); 
				 
				 Response response = request.delete("/"+ petid); 
				 
				 int statusCode = response.getStatusCode();
				// System.out.println(response.asString());
				 Assert.assertEquals(statusCode, 200);
				
			}	
	
	
}
